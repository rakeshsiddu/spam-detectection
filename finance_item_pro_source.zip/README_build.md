# Finance & Item Pro (Flutter)

Tracks items & finance with predefined items, collector/person, payment method (cash/online), clear dates, analytics, prediction, peak times, and PDF/email sharing.

## Features mapped to your requirements
1. **Fast & friendly**: single-screen dashboard + quick Add dialog.
2. **Predefined items**: Manage Catalog (name & default price). Select item when adding an entry.
3. **Money collection**: Track who collected (**Owner** / employee name) and **Cash/Online**.
4. **Totals**: See totals **by collector** and **by payment method** for any date range.
5. **Date/Day**: Each entry stores date & time; list shows day (Mon/Tue...).
6. **Analytics**: buttons for **This Month**, **This Week**, **Weekend** + simple **7‑day prediction**.
7. **Peak time**: Hour-of-day line chart shows high/low selling times.
8. **Reports**: Generate a PDF and **share/email**. Optional scheduled weekly/monthly reminders (Android Workmanager).

## Build APK
```bash
flutter pub get
flutter run           # test
flutter build apk --release
# apk at build/app/outputs/flutter-apk/app-release.apk
```

### Android setup (Workmanager)
This template registers weekly/monthly background callbacks (no-op). If you want the job to auto-generate & email reports, you'd need SMTP creds or a small backend. Current flow: app schedules reminders; you tap the notification and share the PDF via Gmail.

## Optional next steps
- CSV import/export
- Average cost & profit per sale
- Low-stock alerts
- Auto-email via SMTP (mailer package)