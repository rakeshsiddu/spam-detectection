import 'dart:convert';

class CatalogItem {
  final String id;
  final String name;
  final double price;

  CatalogItem({required this.id, required this.name, required this.price});

  CatalogItem copyWith({String? name, double? price}) =>
      CatalogItem(id: id, name: name ?? this.name, price: price ?? this.price);

  Map<String, dynamic> toMap() => {'id': id, 'name': name, 'price': price};
  static CatalogItem fromMap(Map<String, dynamic> m) => CatalogItem(
        id: m['id'] as String,
        name: m['name'] as String,
        price: (m['price'] as num).toDouble(),
      );
}

enum PaymentMethod { cash, online }

class Entry {
  final String id;
  final DateTime dateTime;
  final String itemId;
  final String itemName; // denormalized for simplicity
  final double unitPrice;
  final int qty; // +in / -out
  final String type; // Purchase/Sale/Adjust
  final String collectedBy; // Owner / Employee name
  final PaymentMethod payment;
  final String notes;

  Entry({
    required this.id,
    required this.dateTime,
    required this.itemId,
    required this.itemName,
    required this.unitPrice,
    required this.qty,
    required this.type,
    required this.collectedBy,
    required this.payment,
    required this.notes,
  });

  double get lineTotal => unitPrice * qty;

  Map<String, dynamic> toMap() => {
        'id': id,
        'dateTime': dateTime.toIso8601String(),
        'itemId': itemId,
        'itemName': itemName,
        'unitPrice': unitPrice,
        'qty': qty,
        'type': type,
        'collectedBy': collectedBy,
        'payment': payment.name,
        'notes': notes,
      };

  static Entry fromMap(Map<String, dynamic> m) => Entry(
        id: m['id'] as String,
        dateTime: DateTime.parse(m['dateTime'] as String),
        itemId: m['itemId'] as String,
        itemName: m['itemName'] as String,
        unitPrice: (m['unitPrice'] as num).toDouble(),
        qty: (m['qty'] as num).toInt(),
        type: m['type'] as String,
        collectedBy: m['collectedBy'] as String? ?? 'Owner',
        payment: (m['payment'] as String) == 'online' ? PaymentMethod.online : PaymentMethod.cash,
        notes: m['notes'] as String? ?? '',
      );
}

class AppState {
  final List<CatalogItem> catalog;
  final List<Entry> entries;
  final List<String> employees; // includes 'Owner' as first

  AppState({
    required this.catalog,
    required this.entries,
    required this.employees,
  });

  Map<String, dynamic> toMap() => {
        'catalog': catalog.map((e) => e.toMap()).toList(),
        'entries': entries.map((e) => e.toMap()).toList(),
        'employees': employees,
      };

  static AppState fromMap(Map<String, dynamic> m) => AppState(
        catalog:
            (m['catalog'] as List).map((e) => CatalogItem.fromMap(Map<String, dynamic>.from(e))).toList(),
        entries: (m['entries'] as List).map((e) => Entry.fromMap(Map<String, dynamic>.from(e))).toList(),
        employees: (m['employees'] as List).map((e) => e.toString()).toList(),
      );
}