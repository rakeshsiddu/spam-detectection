import 'dart:io';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'models.dart';
import 'analytics.dart';

class ReportService {
  static Future<File> buildReportPdf({
    required List<Entry> entries,
    required String title,
  }) async {
    final doc = pw.Document();
    final df = DateFormat('yyyy-MM-dd HH:mm');
    final currency = NumberFormat.currency(symbol: '₹');
    final a = computeAnalytics(entries);

    doc.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Header(level: 0, child: pw.Text(title, style: pw.TextStyle(fontSize: 18))),
          pw.Paragraph(
            text:
                'Generated on ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}',
          ),
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            headerDecoration: const pw.BoxDecoration(),
            headers: ['Purchase Spend', 'Sales Value', 'Net Cash Flow', 'Stock Value (approx.)'],
            data: [
              [
                currency.format(a.totalPurchases),
                currency.format(a.totalSalesAbs),
                currency.format(a.netCashFlow),
                currency.format(_stockValueApprox(entries)),
              ]
            ],
          ),
          pw.SizedBox(height: 12),
          pw.Text('Transactions', style: const pw.TextStyle(fontSize: 14)),
          pw.Table.fromTextArray(
            headers: ['Date', 'Item', 'Price', 'Qty', 'Type', 'By', 'Payment', 'Total'],
            data: entries.map((e) {
              return [
                df.format(e.dateTime),
                e.itemName,
                currency.format(e.unitPrice),
                e.qty.toString(),
                e.type,
                e.collectedBy,
                e.payment.name,
                currency.format(e.lineTotal),
              ];
            }).toList(),
            cellAlignment: pw.Alignment.centerLeft,
          ),
        ],
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/report_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await doc.save());
    return file;
  }

  static double _stockValueApprox(List<Entry> entries) {
    final lastPrice = <String, double>{};
    final qty = <String, int>{};
    for (final e in entries) {
      lastPrice[e.itemName] = e.unitPrice;
      qty.update(e.itemName, (v) => v + e.qty, ifAbsent: () => e.qty);
    }
    double total = 0;
    qty.forEach((k, v) {
      total += v * (lastPrice[k] ?? 0);
    });
    return total;
  }

  static Future<void> sharePdf(File file) async {
    await Share.shareXFiles([XFile(file.path)], text: 'Inventory & Finance Report');
  }
}