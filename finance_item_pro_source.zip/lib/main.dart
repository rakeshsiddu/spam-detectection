import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:workmanager/workmanager.dart';
import 'models.dart';
import 'storage.dart';
import 'analytics.dart';
import 'report.dart';

void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    // In a real app, you'd load state and generate a PDF.
    // Here we just signal success.
    return Future.value(true);
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Finance & Items',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final NumberFormat currency = NumberFormat.currency(symbol: '₹');
  AppState? state;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await Store.load();
    setState(() => state = s);
  }

  Future<void> _save() async {
    if (state != null) await Store.save(state!);
  }

  void _addOrEditCatalog([CatalogItem? existing]) async {
    final result = await showDialog<CatalogItem>(
      context: context,
      builder: (c) => _CatalogDialog(existing: existing),
    );
    if (result != null) {
      setState(() {
        final list = [...state!.catalog];
        if (existing == null) {
          list.add(result);
        } else {
          final i = list.indexWhere((e) => e.id == existing.id);
          if (i != -1) list[i] = result;
        }
        state = AppState(catalog: list, entries: state!.entries, employees: state!.employees);
      });
      _save();
    }
  }

  void _addOrEditEntry([Entry? existing]) async {
    final result = await showDialog<Entry>(
      context: context,
      builder: (c) => _EntryDialog(
        catalog: state!.catalog,
        employees: state!.employees,
        existing: existing,
      ),
    );
    if (result != null) {
      setState(() {
        final list = [...state!.entries];
        if (existing == null) {
          list.insert(0, result);
        } else {
          final i = list.indexWhere((e) => e.id == existing.id);
          if (i != -1) list[i] = result;
        }
        state = AppState(catalog: state!.catalog, entries: list, employees: state!.employees);
      });
      _save();
    }
  }

  void _deleteEntry(Entry e) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete entry?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete'))
        ],
      ),
    );
    if (ok == true) {
      setState(() {
        final list = [...state!.entries]..removeWhere((x) => x.id == e.id);
        state = AppState(catalog: state!.catalog, entries: list, employees: state!.employees);
      });
      _save();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (state == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final a = computeAnalytics(state!.entries);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Finance & Items'),
        actions: [
          IconButton(onPressed: () => _addOrEditEntry(), icon: const Icon(Icons.add)),
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'catalog') _showCatalog();
              if (v == 'report') _shareReport();
              if (v == 'schedule') _scheduleJobs();
            },
            itemBuilder: (c) => const [
              PopupMenuItem(value: 'catalog', child: Text('Manage Catalog')),
              PopupMenuItem(value: 'report', child: Text('Share PDF Report')),
              PopupMenuItem(value: 'schedule', child: Text('Schedule Weekly/Monthly Reminder')),
            ],
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _KpiRow(
            purchase: a.totalPurchases,
            sales: a.totalSalesAbs,
            net: a.netCashFlow,
            stock: _stockValueApprox(state!.entries),
          ),
          const SizedBox(height: 12),
          _Section(title: 'Analytics (select range)', child: _RangeAnalytics(entries: state!.entries)),
          const SizedBox(height: 12),
          _Section(
            title: 'Peak Time (hour of day)',
            child: _PeakChart(qtyByHour: a.qtyByHour),
          ),
          const SizedBox(height: 12),
          _Section(
            title: 'Entries',
            child: Column(
              children: state!.entries.map((e) => _EntryTile(
                e: e,
                currency: currency,
                onEdit: () => _addOrEditEntry(e),
                onDelete: () => _deleteEntry(e),
              )).toList(),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addOrEditEntry(),
        label: const Text('Add Entry'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  void _showCatalog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (c) => DraggableScrollableSheet(
        expand: false,
        builder: (c, controller) => Scaffold(
          appBar: AppBar(
            title: const Text('Catalog (predefined items)'),
            actions: [
              IconButton(onPressed: () => _addOrEditCatalog(), icon: const Icon(Icons.add)),
            ],
          ),
          body: ListView(
            controller: controller,
            children: state!.catalog.map((it) => ListTile(
              title: Text(it.name),
              subtitle: Text('Price: ₹${it.price.toStringAsFixed(2)}'),
              trailing: IconButton(icon: const Icon(Icons.edit), onPressed: () => _addOrEditCatalog(it)),
            )).toList(),
          ),
        ),
      ),
    );
  }

  Future<void> _shareReport() async {
    final file = await ReportService.buildReportPdf(entries: state!.entries, title: 'Weekly/Monthly Report');
    await ReportService.sharePdf(file);
  }

  Future<void> _scheduleJobs() async {
    // Schedules weekly and monthly background callbacks (Android)
    await Workmanager().cancelAll();
    await Workmanager().registerPeriodicTask('weeklyTask', 'weeklyTask',
        frequency: const Duration(days: 7));
    await Workmanager().registerPeriodicTask('monthlyTask', 'monthlyTask',
        frequency: const Duration(days: 28));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reminders scheduled.')));
    }
  }

  double _stockValueApprox(List<Entry> entries) {
    final lastPrice = <String, double>{};
    final qty = <String, int>{};
    for (final e in entries) {
      lastPrice[e.itemName] = e.unitPrice;
      qty.update(e.itemName, (v) => v + e.qty, ifAbsent: () => e.qty);
    }
    double total = 0;
    qty.forEach((k, v) => total += v * (lastPrice[k] ?? 0));
    return total;
  }
}

class _KpiRow extends StatelessWidget {
  final double purchase, sales, net, stock;
  const _KpiRow({required this.purchase, required this.sales, required this.net, required this.stock});

  String _fmt(double v) => NumberFormat.compactCurrency(symbol: '₹').format(v);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _Kpi(label: 'Purchase Spend', value: _fmt(purchase))),
        const SizedBox(width: 8),
        Expanded(child: _Kpi(label: 'Sales Value', value: _fmt(sales))),
        const SizedBox(width: 8),
        Expanded(child: _Kpi(label: 'Net Cash Flow', value: _fmt(net))),
        const SizedBox(width: 8),
        Expanded(child: _Kpi(label: 'Stock Value', value: _fmt(stock))),
      ],
    );
  }
}

class _Kpi extends StatelessWidget {
  final String label, value;
  const _Kpi({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: Theme.of(context).textTheme.labelMedium),
          const SizedBox(height: 6),
          Text(value, style: Theme.of(context).textTheme.titleLarge),
        ]),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final Widget child;
  const _Section({required this.title, required this.child});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      Card(child: Padding(padding: const EdgeInsets.all(12), child: child)),
    ]);
  }
}

class _RangeAnalytics extends StatefulWidget {
  final List<Entry> entries;
  const _RangeAnalytics({required this.entries});

  @override
  State<_RangeAnalytics> createState() => _RangeAnalyticsState();
}

class _RangeAnalyticsState extends State<_RangeAnalytics> {
  late DateTime from;
  late DateTime to;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    from = DateTime(now.year, now.month, 1);
    to = DateTime(now.year, now.month + 1, 0);
  }

  @override
  Widget build(BuildContext context) {
    final list = filterByRange(widget.entries, from, to);
    final a = computeAnalytics(list);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton.tonal(onPressed: () => setState(() {
              final now = DateTime.now();
              from = DateTime(now.year, now.month, 1);
              to = DateTime(now.year, now.month + 1, 0);
            }), child: const Text('This Month')),
            FilledButton.tonal(onPressed: () => setState(() {
              final now = DateTime.now();
              final weekStart = now.subtract(Duration(days: now.weekday - 1));
              from = DateTime(weekStart.year, weekStart.month, weekStart.day);
              to = from.add(const Duration(days: 6));
            }), child: const Text('This Week')),
            FilledButton.tonal(onPressed: () => setState(() {
              // Weekend (Sat-Sun) around current week
              final now = DateTime.now();
              final saturday = now.subtract(Duration(days: (now.weekday % 7)));
              final sunday = saturday.add(const Duration(days: 1));
              from = DateTime(saturday.year, saturday.month, saturday.day);
              to = DateTime(sunday.year, sunday.month, sunday.day);
            }), child: const Text('Weekend')),
          ],
        ),
        const SizedBox(height: 12),
        Text('Totals by Collector & Payment'),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: [
            _ChipList(map: a.amountByCollector.map((k, v) => MapEntry('By $k', v))),
            _ChipList(map: a.amountByPayment),
          ],
        ),
        const SizedBox(height: 12),
        Text('Prediction (next 7 days): ₹${NumberFormat.compact().format(a.weeklyPrediction)}'),
        const SizedBox(height: 12),
        SizedBox(
          height: 200,
          child: BarChart(BarChartData(
            titlesData: FlTitlesData(
              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v, meta) {
                final items = a.qtyByItem.keys.toList()..sort();
                final i = v.toInt();
                if (i < 0 || i >= items.length) return const SizedBox.shrink();
                return SideTitleWidget(axisSide: meta.axisSide, child: Text(items[i], style: const TextStyle(fontSize: 10)));
              })),
            ),
            barGroups: () {
              final items = a.qtyByItem.keys.toList()..sort();
              return List.generate(items.length, (i) {
                final k = items[i];
                final val = (a.qtyByItem[k] ?? 0).toDouble().abs();
                return BarChartGroupData(x: i, barRods: [BarChartRodData(toY: val)]);
              });
            }(),
          )),
        ),
      ],
    );
  }
}

class _ChipList extends StatelessWidget {
  final Map<String, double> map;
  const _ChipList({required this.map});
  @override
  Widget build(BuildContext context) {
    final currency = NumberFormat.currency(symbol: '₹');
    return Wrap(
      spacing: 8,
      children: map.entries.map((e) => Chip(label: Text('${e.key}: ${currency.format(e.value)}'))).toList(),
    );
  }
}

class _PeakChart extends StatelessWidget {
  final Map<int, int> qtyByHour;
  const _PeakChart({required this.qtyByHour});

  @override
  Widget build(BuildContext context) {
    final hours = List<int>.generate(24, (i) => i);
    return SizedBox(
      height: 200,
      child: LineChart(LineChartData(
        titlesData: FlTitlesData(
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        lineBarsData: [
          LineChartBarData(
            spots: hours.map((h) => FlSpot(h.toDouble(), (qtyByHour[h] ?? 0).toDouble())).toList(),
            isCurved: true,
            dotData: const FlDotData(show: false),
          )
        ],
      )),
    );
  }
}

class _EntryTile extends StatelessWidget {
  final Entry e;
  final NumberFormat currency;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const _EntryTile({required this.e, required this.currency, required this.onEdit, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('yyyy-MM-dd HH:mm (EEE)');
    return Card(
      child: ListTile(
        title: Text('${e.itemName} • ${e.type} • ${e.qty} @ ${currency.format(e.unitPrice)}'),
        subtitle: Text('${df.format(e.dateTime)}  •  By: ${e.collectedBy}  •  ${e.payment.name.toUpperCase()}'
            '${e.notes.isNotEmpty ? '\n${e.notes}' : ''}'),
        trailing: Wrap(spacing: 4, children: [
          IconButton(onPressed: onEdit, icon: const Icon(Icons.edit)),
          IconButton(onPressed: onDelete, icon: const Icon(Icons.delete)),
        ]),
      ),
    );
  }
}

class _CatalogDialog extends StatefulWidget {
  final CatalogItem? existing;
  const _CatalogDialog({this.existing});

  @override
  State<_CatalogDialog> createState() => _CatalogDialogState();
}

class _CatalogDialogState extends State<_CatalogDialog> {
  late TextEditingController nameC;
  late TextEditingController priceC;

  @override
  void initState() {
    super.initState();
    nameC = TextEditingController(text: widget.existing?.name ?? '');
    priceC = TextEditingController(text: widget.existing?.price.toString() ?? '');
  }

  @override
  void dispose() {
    nameC.dispose();
    priceC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.existing == null ? 'Add Catalog Item' : 'Edit Catalog Item'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: nameC, decoration: const InputDecoration(labelText: 'Item Name')),
        TextField(controller: priceC, decoration: const InputDecoration(labelText: 'Default Price'),
          keyboardType: const TextInputType.numberWithOptions(decimal: true)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          final name = nameC.text.trim();
          final price = double.tryParse(priceC.text.trim()) ?? 0;
          if (name.isEmpty) return;
          final id = widget.existing?.id ?? DateTime.now().millisecondsSinceEpoch.toString();
          final item = CatalogItem(id: id, name: name, price: price);
          Navigator.pop(context, item);
        }, child: const Text('Save')),
      ],
    );
  }
}

class _EntryDialog extends StatefulWidget {
  final List<CatalogItem> catalog;
  final List<String> employees;
  final Entry? existing;
  const _EntryDialog({required this.catalog, required this.employees, this.existing});

  @override
  State<_EntryDialog> createState() => _EntryDialogState();
}

class _EntryDialogState extends State<_EntryDialog> {
  String? itemId;
  late TextEditingController priceC;
  late TextEditingController qtyC;
  String type = 'Sale';
  String collector = 'Owner';
  PaymentMethod payment = PaymentMethod.cash;
  late TextEditingController notesC;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    itemId = e?.itemId ?? (widget.catalog.isNotEmpty ? widget.catalog.first.id : null);
    priceC = TextEditingController(text: e?.unitPrice.toString() ?? _defaultPriceFor(itemId).toString());
    qtyC = TextEditingController(text: e?.qty.toString() ?? '');
    type = e?.type ?? 'Sale';
    collector = e?.collectedBy ?? 'Owner';
    payment = e?.payment ?? PaymentMethod.cash;
    notesC = TextEditingController(text: e?.notes ?? '');
  }

  double _defaultPriceFor(String? id) {
    final it = widget.catalog.where((x) => x.id == id).toList();
    return it.isNotEmpty ? it.first.price : 0.0;
    }

  @override
  void dispose() {
    priceC.dispose();
    qtyC.dispose();
    notesC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.existing == null ? 'Add Entry' : 'Edit Entry'),
      content: SingleChildScrollView(
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: itemId,
              items: widget.catalog.map((e) => DropdownMenuItem(value: e.id, child: Text(e.name))).toList(),
              onChanged: (v) => setState(() { itemId = v; priceC.text = _defaultPriceFor(v).toString(); }),
              decoration: const InputDecoration(labelText: 'Item'),
            ),
            TextField(
              controller: priceC,
              decoration: const InputDecoration(labelText: 'Unit Price'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            TextField(
              controller: qtyC,
              decoration: const InputDecoration(labelText: 'Quantity (+in / -out)'),
              keyboardType: TextInputType.number,
            ),
            DropdownButtonFormField<String>(
              value: type,
              items: const [
                DropdownMenuItem(value: 'Purchase', child: Text('Purchase')),
                DropdownMenuItem(value: 'Sale', child: Text('Sale')),
                DropdownMenuItem(value: 'Adjust', child: Text('Adjust')),
              ],
              onChanged: (v) => setState(() => type = v ?? 'Sale'),
              decoration: const InputDecoration(labelText: 'Type'),
            ),
            DropdownButtonFormField<String>(
              value: collector,
              items: widget.employees.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (v) => setState(() => collector = v ?? 'Owner'),
              decoration: const InputDecoration(labelText: 'Collected By'),
            ),
            DropdownButtonFormField<PaymentMethod>(
              value: payment,
              items: const [
                DropdownMenuItem(value: PaymentMethod.cash, child: Text('Cash')),
                DropdownMenuItem(value: PaymentMethod.online, child: Text('Online')),
              ],
              onChanged: (v) => setState(() => payment = v ?? PaymentMethod.cash),
              decoration: const InputDecoration(labelText: 'Payment Method'),
            ),
            TextField(controller: notesC, decoration: const InputDecoration(labelText: 'Notes')),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          if (itemId == null) return;
          final cat = widget.catalog.firstWhere((e) => e.id == itemId);
          final id = widget.existing?.id ?? DateTime.now().millisecondsSinceEpoch.toString();
          final entry = Entry(
            id: id,
            dateTime: DateTime.now(),
            itemId: cat.id,
            itemName: cat.name,
            unitPrice: double.tryParse(priceC.text.trim()) ?? 0,
            qty: int.tryParse(qtyC.text.trim()) ?? 0,
            type: type,
            collectedBy: collector,
            payment: payment,
            notes: notesC.text.trim(),
          );
          Navigator.pop(context, entry);
        }, child: const Text('Save')),
      ],
    );
  }
}