import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class Store {
  static const String key = 'finance_item_pro_state_v1';

  static Future<AppState> load() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(key);
    if (raw == null) {
      // seed
      final seed = AppState(
        catalog: [
          CatalogItem(id: '1', name: 'Sample Widget', price: 100.0),
          CatalogItem(id: '2', name: 'Gadget', price: 150.0),
        ],
        entries: [],
        employees: ['Owner', 'Employee A', 'Employee B'],
      );
      await save(seed);
      return seed;
    }
    final Map<String, dynamic> m = jsonDecode(raw);
    return AppState.fromMap(m);
  }

  static Future<void> save(AppState state) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(key, jsonEncode(state.toMap()));
  }
}