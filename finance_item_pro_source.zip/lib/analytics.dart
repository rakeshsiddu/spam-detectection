import 'package:collection/collection.dart';
import 'models.dart';

class AnalyticsResult {
  final double totalPurchases;
  final double totalSalesAbs;
  final double netCashFlow;
  final Map<String, int> qtyByItem;
  final Map<String, double> amountByCollector; // Owner/Employee
  final Map<String, double> amountByPayment; // Cash/Online
  final Map<DateTime, double> netByDay;
  final Map<int, int> qtyByHour; // 0-23
  final double weeklyPrediction; // simple next-7-day sum using moving average

  AnalyticsResult({
    required this.totalPurchases,
    required this.totalSalesAbs,
    required this.netCashFlow,
    required this.qtyByItem,
    required this.amountByCollector,
    required this.amountByPayment,
    required this.netByDay,
    required this.qtyByHour,
    required this.weeklyPrediction,
  });
}

AnalyticsResult computeAnalytics(List<Entry> entries) {
  double purchases = 0, salesAbs = 0, net = 0;
  final qtyByItem = <String, int>{};
  final amountByCollector = <String, double>{};
  final amountByPayment = <String, double>{};
  final netByDay = <DateTime, double>{};
  final qtyByHour = <int, int>{};

  for (final e in entries) {
    final lt = e.lineTotal;
    net += lt;
    if (e.type == 'Purchase') purchases += lt;
    if (e.type == 'Sale') salesAbs += lt.abs();
    qtyByItem.update(e.itemName, (v) => v + e.qty, ifAbsent: () => e.qty);
    amountByCollector.update(e.collectedBy, (v) => v + lt, ifAbsent: () => lt);
    final pm = e.payment == PaymentMethod.cash ? 'Cash' : 'Online';
    amountByPayment.update(pm, (v) => v + lt, ifAbsent: () => lt);
    final d = DateTime(e.dateTime.year, e.dateTime.month, e.dateTime.day);
    netByDay.update(d, (v) => v + lt, ifAbsent: () => lt);
    qtyByHour.update(e.dateTime.hour, (v) => v + e.qty.abs(), ifAbsent: () => e.qty.abs());
  }

  // Simple prediction: moving average of last 4 weeks daily net * 7
  final daysSorted = netByDay.keys.toList()..sort();
  double weeklyPred = 0;
  if (daysSorted.isNotEmpty) {
    final values = daysSorted.map((d) => netByDay[d] ?? 0).toList();
    final window = values.length < 28 ? values.length : 28;
    if (window > 0) {
      final avg = values.sublist(values.length - window).sum / window;
      weeklyPred = avg * 7;
    }
  }

  return AnalyticsResult(
    totalPurchases: purchases,
    totalSalesAbs: salesAbs,
    netCashFlow: net,
    qtyByItem: qtyByItem,
    amountByCollector: amountByCollector,
    amountByPayment: amountByPayment,
    netByDay: netByDay,
    qtyByHour: qtyByHour,
    weeklyPrediction: weeklyPred,
  );
}

List<Entry> filterByRange(List<Entry> entries, DateTime from, DateTime to) {
  return entries
      .where((e) => !e.dateTime.isBefore(from) && !e.dateTime.isAfter(to))
      .toList();
}

bool isWeekend(DateTime d) => d.weekday == DateTime.saturday || d.weekday == DateTime.sunday;